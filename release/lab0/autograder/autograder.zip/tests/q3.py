test = {   'name': 'q3',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> # run this cell to check your answer in the cell above\n'
                                               '>>> assert sha1(str(y).encode(\'utf8\')).hexdigest() == \'b1d5781111d84f7b3fe45a0852e59758cd7a87e5\', "y should have the value of 10."\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
